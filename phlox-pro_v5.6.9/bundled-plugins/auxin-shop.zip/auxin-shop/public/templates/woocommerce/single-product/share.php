<?php
/**
 * Only the last line is like share.php template file
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

?>
<?php do_action( 'auxshp-before-single-share' ); ?>
<?php $share_icon = auxin_get_option( 'product_single_share_button_icon', 'auxicon-share' ) ; ?>
<div class="auxshp-share-wrapper">
    <div class="aux-share-btn aux-tooltip-socials aux-tooltip-dark aux-socials">
        <?php if ( 'icon' == auxin_get_option( 'product_single_share_button_type', 'icon' ) ) { ?>
            <span class="aux-icon <?php echo esc_attr( $share_icon ); ?>"></span>
        <?php } ?>
        <span class="aux-text"><?php _e( 'Share', 'auxin-shop' ); ?></span>
    </div>
</div>

<?php do_action( 'auxshp-after-single-share' ); ?>

<?php do_action( 'woocommerce_share' ); // Sharing plugins can hook into here ?>