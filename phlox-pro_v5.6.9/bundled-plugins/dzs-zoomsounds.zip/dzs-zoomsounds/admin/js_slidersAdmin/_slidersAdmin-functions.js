

export function getSliderItemContainerFromSettingField($t){

  let $sliderItem = null;
  if ($t.parent().parent().parent().parent().hasClass('slider-item')) {
    $sliderItem = $t.parent().parent().parent().parent();
  }
  if ($t.parent().parent().parent().parent().parent().hasClass('slider-item')) {
    $sliderItem = $t.parent().parent().parent().parent().parent();
  }

  if ($t.parent().parent().parent().parent().parent().parent().hasClass('slider-item')) {
    $sliderItem = $t.parent().parent().parent().parent().parent().parent();
  }
  if ($t.parent().parent().parent().parent().parent().parent().parent().hasClass('slider-item')) {
    $sliderItem = $t.parent().parent().parent().parent().parent().parent().parent();
  }
  if ($t.parent().parent().parent().parent().parent().parent().parent().parent().hasClass('slider-item')) {
    $sliderItem = $t.parent().parent().parent().parent().parent().parent().parent().parent();
  }

  if ($t.parent().parent().parent().parent().parent().parent().parent().parent().parent().hasClass('slider-item')) {
    $sliderItem = $t.parent().parent().parent().parent().parent().parent().parent().parent().parent();
  }

  return $sliderItem;
}