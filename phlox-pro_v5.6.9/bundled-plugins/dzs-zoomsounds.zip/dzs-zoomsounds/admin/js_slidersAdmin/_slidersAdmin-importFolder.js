

export function importFolderInit($){

  $(document).on('click.sliders_admin', '.slider-item, .slider-item > .divimage, .add-btn-new, .add-btn-existing-media, .delete-btn,.clone-item-btn, .btn-import-folder, #import-options-link-wrap, .button-primary', handle_mouse);


  function handle_mouse(){
    var _t = $(this);
    if (_t.hasClass('btn-import-folder')) {
      // console.info('rree');

      var data = {
        action: 'dzsap_import_folder',
        payload: $('*[data-aux-name="folder_location"]').val(),
      }

      jQuery.ajax({
        type: "POST",
        url: window.ajaxurl,
        data: data,
        success: function (response) {

          response = parse_response(response);
          console.warn('response - ', response);


          if (response.report_message) {
            if (window) {

              show_feedback(response.report_message);
            }
          }


          if (response.files) {
            for (var i in response.files) {
              var cach = response.files[i];


              $('.for-feed_mode-import-folder').addClass('loading');
              var queue_call = {
                'type': 'create_item'
                , 'term_id': $slidersCon.attr('data-term_id')
                , 'term_slug': $slidersCon.attr('data-term-slug')
                , 'dzsap_meta_item_type': 'audio'
                , 'dzsap_meta_item_path': cach.path
                , 'post_title': cach.name
                , 'dzsap_meta_item_source': cach.url
              }


              // -- let us see if we already have this

              var sw_continue = true;
              $('.slider-item').each(function () {
                var _t4 = $(this);

                // console.info('_t4.find(\'input[name="dzsap_meta_item_source"]\').val() - ',_t4.find('input[name="dzsap_meta_item_source"]').val(),cach.url);


                if (_t4.find('input[name="dzsap_meta_item_source"]').val() == cach.url) {
                  sw_continue = false;
                }
              });

              if (sw_continue) {

                queue_call['dzsap_meta_order_' + slider_term_id] = 1 + _sliderItems.children().length + 0;
                ajax_queue.push(queue_call);

                // console.info('ajax_queue - ',ajax_queue);
                prepare_send_queue_calls(10);


                setTimeout(function () {


                  dzstaa_init('.dzs-tabs-meta-item', {
                    init_each: true
                  });


                  dzssel_init('select.dzs-style-me', {init_each: true});
                  // $('*[data-aux-name="feed_mode"]').find('.bigoption').eq(0).trigger('click');
                  $('*[data-aux-name="feed_mode"]').parent().find('.bigoption').eq(0).trigger('click');
                }, 1000);
              }
              setTimeout(function () {
                $('.for-feed_mode-import-folder').removeClass('loading');
              }, 1000);
            }

          }
        },
        error: function (arg) {
          if (typeof window.console != "undefined") {
            console.warn('Got this from the server / error: ' + arg);
          }
          ;
          //ajax_queue = [];
        }
      });


      return false;
    }

  }
}