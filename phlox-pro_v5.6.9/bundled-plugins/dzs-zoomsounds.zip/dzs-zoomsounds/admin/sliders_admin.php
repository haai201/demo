<?php


// -- in action init
$dzsap_slidersAdmin_fixHackConfictsForOrder_metaQuery = null;

//add_action( 'dzsap_sliders_add_form_fields', 'dzsap_sliders_admin_add_feature_group_field', 10, 2 );
add_action('dzsap_sliders_edit_form_fields', 'dzsap_sliders_admin_add_feature_group_field', 10, 10);

add_filter('dzsap_sliders_row_actions', 'dzsap_sliders_admin_duplicate_post_link', 10, 2);
add_action('admin_action_dzsap_duplicate_slider_term', 'dzsap_action_dzsap_duplicate_slider_term', 10, 2);


add_action('admin_init', 'dzsap_sliders_admin_init', 1000);

/**
 * rms_ plugin acts up with the order
 * @param $targetQuery
 */
function dzsap_slidersAdmin_fixHackConfictsForOrder($targetQuery){

  global $dzsap_slidersAdmin_fixHackConfictsForOrder_metaQuery;

  if(isset($targetQuery->query_vars) && $targetQuery->query_vars['post_type']===DZSAP_REGISTER_POST_TYPE_NAME){
    $targetQuery->query_vars['meta_query'] = $dzsap_slidersAdmin_fixHackConfictsForOrder_metaQuery;
  }
}

function dzsap_sliders_admin_generate_item($po) {
  global $dzsap;


  $fout = '';
  $thumb = '';
  $thumb_from_meta = '';
  // -- we need real location, not insert-id
  $struct_uploader = '<div class="dzs-wordpress-uploader "><a rel="nofollow" href="#" class="button-secondary">' . esc_html__('Upload', DZSAP_ID) . '</a></div>';


  $po_id = '';
  if ($po && is_int($po->ID)) {

    $thumb = DZSZoomSoundsHelper::get_post_thumb_src($po->ID);

    $po_id = $po->ID;
//            echo ' thumb - ';
//            print_r($thumb);


    $thumb_from_meta = get_post_meta($po->ID, 'dzsap_meta_item_thumb', true);
  }

  if ($thumb_from_meta) {

    $thumb = $thumb_from_meta;
  }

  $thumb_url = '';
  if ($thumb) {
    $thumb_url = DZSZoomSoundsHelper::getImageSourceFromId($thumb);
  }


  if ($po_id) {

    $fout .= '<div class="slider-item dzstooltip-con for-click';

    if ($po && $po->ID == 'placeholder') {
      $fout .= ' slider-item--placeholder';
    }

    $fout .= '" data-id="' . $po->ID . '">';


//            $fout.='<div class="auxdev-dzs-meta-order" style="display:none; " >'.get_post_meta($po->ID,'dzsap_meta_order_54',true).'</div>';


    $fout .= '<div class="divimage" style="background-image:url(' . $thumb_url . ');"></div>';
    $fout .= '<div class="slider-item--title" >' . $po->post_title . '</div>';

    $fout .= '<div class="delete-btn item-control-btn"><i class="fa fa-times-circle-o"></i></div>
<div class="clone-item-btn item-control-btn"><i class="fa fa-clone"></i></div>
<div class="dzstooltip dzstooltip--sliders-admin   arrow-top talign-start style-rounded color-dark-light ">
<div class="dzstooltip--selector-top"></div>
<div class="dzstooltip--inner">
<div class="dzstooltip--content">';


    $fout .= '<div class="dzs-tabs dzs-tabs-meta-item  skin-default " data-options=\'{ "design_tabsposition" : "top","design_transition": "fade","design_tabswidth": "default","toggle_breakpoint" : "200","settings_appendWholeContent": "true","toggle_type": "accordion"}
\' style=\'padding: 0;\'>
<div class="dzs-tab-tobe">
<div class="tab-menu ">' . esc_html__("General", DZSAP_ID) . '
    </div>
<div class="tab-content tab-content-item-meta-cat-main">
' . dzsap_sliders_admin_generate_item_meta_cat('main', $po) . '
    </div>
    </div>';


    foreach ($dzsap->item_meta_categories_lng as $lab => $val) {
      ob_start();
      ?>
      <div class="dzs-tab-tobe">
      <div class="tab-menu ">
        <?php
        echo($val);
        ?>
      </div>
      <div class="tab-content tab-content-cat-<?php echo $lab; ?>">


        <?php
        echo dzsap_sliders_admin_generate_item_meta_cat($lab, $po);
        ?>


      </div>
      </div><?php
      $fout .= ob_get_clean();
    }

    $fout .= '</div>';// -- end tabs


    $fout .= '</div>';
    $fout .= '</div>';
    $fout .= '</div>';
    $fout .= '</div>';
  }

  return $fout;
}

function dzsap_sliders_admin_generate_item_meta_cat($cat, $po, $pargs = array()) {

  // -- generate options for sliders admin category
  global $dzsap;


  $margs = array(

    'for_shortcode_generator' => false,
    'for_item_meta' => false,
  );

  $margs = array_merge($margs, $pargs);

  $fout = '';
  // -- we need real location, not insert-id
  $struct_uploader = '<div class="dzs-wordpress-uploader ">
<a rel="nofollow" href="#" class="button-secondary">' . esc_html__('Upload', DZSAP_ID) . '</a>
</div>';


  // -- generate item category ( for sliders admin )
  foreach ($dzsap->options_item_meta as $lab => $oim) {


    $oim = array_merge(array(
      'category' => '',
      'no_preview' => '',
      'it_is_for' => 'item_meta',
      'input_extra_classes' => '',
    ), $oim);


    // -- some sanitizing
    if ($oim['type'] == 'image') {
      $oim['type'] = 'attach';
    }


    if (isset($oim['options'])) {
      if (isset($oim['choices']) == false) {
        $oim['choices'] = $oim['options'];
      }
    }

    if ($oim['category'] == $cat) {

    } else {
      if ($cat == 'main') {
        if ($oim['category'] == '') {


        } else {
          continue;
        }
      } else {
        continue;
      }
    }

    if ($oim['it_is_for'] == 'shortcode_generator') {


//	            print_rr($margs);
      if ($margs['for_shortcode_generator'] == false) {
        continue;
      }
    }

    if ($oim['it_is_for'] == 'for_item_meta_only') {


//	            print_rr($margs);
      if ($margs['for_item_meta'] == false) {
        continue;
      }
    }


    if ($oim['type'] == 'dzs_row') {
      $fout .= '<section class="dzs-row">';
      continue;

    }
    if ($oim['type'] == 'dzs_col_md_6') {
      $fout .= '<section class="dzs-col-md-6">';
      continue;

    }
    if ($oim['type'] == 'dzs_col_md_12') {
      $fout .= '<section class="dzs-col-md-6">';
      continue;

    }

    if ($oim['type'] == 'dzs_row_end') {
      $fout .= '</section><!--dzs row end-->';
      continue;

    }
    if ($oim['type'] == 'dzs_col_md_6_end') {
      $fout .= '</section><!--dzs dzs_col_md_6_end end-->';
      continue;

    }
    if ($oim['type'] == 'dzs_col_md_12_end') {
      $fout .= '</section><!--dzs dzs_col_md_12_end end-->';
      continue;

    }
    if ($oim['type'] == 'custom_html') {
      $fout .= $oim['custom_html'];
      continue;

    }


    $fout .= '<div class="setting ';
    $option_name = $oim['name'];
    $fout .= ' data-option-name-' . $option_name . '';

    if ($oim['type'] == 'attach') {
      $fout .= ' setting-upload';
    }

    $fout .= '" ';

    $fout .= ' data-option-name="' . $option_name . '"';

    if (isset($oim['dependency']) && $oim['dependency']) {
      $fout .= ' data-dependency=\'' . json_encode($oim['dependency']) . '\'';
    }


    $fout .= '>';


    if ((strpos($option_name, 'item_source') || $option_name == 'source')) {

//		        error_log('add attachment id');

      $lab_aux = 'dzsap_meta_source_attachment_id';
      $val_aux = '';
      if ($po) {

        $val_aux = get_post_meta($po->ID, $lab_aux, true);
      }


      $class = 'setting-field shortcode-field';

      if ($margs['for_shortcode_generator']) {
        $class .= ' insert-id';
      }

      // -- source

      $class .= $oim['input_extra_classes'];

      $fout .= DZSHelpers::generate_input_text($lab_aux, array(
        'class' => $class,
        'seekval' => $val_aux,
        'input_type' => 'hidden',
      ));
    }

    $fout .= '<h5 class="setting-label setting-label-item-meta-cat">' . $oim['title'] . '</h5>';


    if ($oim['type'] == 'attach') {


      if ($oim['no_preview'] != 'on') {
        $fout .= '<span class="uploader-preview"></span>';
      }
    }


    if ($margs['for_shortcode_generator']) {
      $option_name = str_replace('dzsap_meta_item_', '', $option_name);
      $option_name = str_replace('dzsap_meta_', '', $option_name);

      if ($option_name == 'the_post_title') {
        $option_name = 'songname';
      }
    }

    $extraattr_input = '';

    if (isset($oim['extraattr_input']) && $oim['extraattr_input']) {
      $extraattr_input .= $oim['extraattr_input'];
    }

    $val = '';

    if ($po && is_int($po->ID)) {

      $val = get_post_meta($po->ID, $option_name, true);
    }

    if ($po && $option_name == 'the_post_title') {
      $val = $po->post_title;
    }
    if ($po && $option_name == 'post_content') {
      $val = $po->post_content;
    }

    $class = 'setting-field medium';

    if ($oim['type'] == 'attach') {
      $class .= ' uploader-target';
    }

    if ($margs['for_shortcode_generator']) {
      $class .= ' shortcode-field';
    }

//        print_rr($oim);
    $class .= $oim['input_extra_classes'];

//      echo 'class - '.$class;
    if ($oim['type'] == 'attach') {


      if (isset($oim['upload_type']) && $oim['upload_type']) {
        $class .= ' upload-type-' . $oim['upload_type'];
      }
      $class .= 'setting-field shortcode-field';

      if ($option_name == 'source' && $margs['for_shortcode_generator']) {
        $class .= ' insert-id';
      }

      $fout .= DZSHelpers::generate_input_text($option_name, array(
        'class' => $class,
        'seekval' => $val,
        'extraattr' => $extraattr_input,
      ));
    }
    if ($oim['type'] == 'text') {
      $fout .= DZSHelpers::generate_input_text($option_name, array(
        'class' => $class,
        'seekval' => $val,
        'extraattr' => $extraattr_input,
      ));
    }
    if ($oim['type'] == 'textarea') {
      $fout .= DZSHelpers::generate_input_textarea($option_name, array(
        'class' => $class,
        'seekval' => $val,
        'extraattr' => $extraattr_input,
      ));
    }
    if ($oim['type'] == 'select') {


      $class = '';

      if (isset($oim['class'])) {
        $class .= $oim['class'];
      }
      $class .= ' dzs-style-me skin-beige setting-field';

      if (isset($oim['select_type']) && $oim['select_type']) {
        $class .= ' ' . $oim['select_type'];
      }
      if ($margs['for_shortcode_generator']) {
        $class .= ' shortcode-field';
      }

      $fout .= DZSHelpers::generate_select($option_name, array(
        'class' => $class,
        'seekval' => $val,
        'options' => $oim['choices'],
        'extraattr' => $extraattr_input,
      ));

      if (isset($oim['select_type']) && $oim['select_type'] == 'opener-listbuttons') {

        $fout .= '<ul class="dzs-style-me-feeder">';

        foreach ($oim['choices_html'] as $oim_html) {

          $fout .= '<li>';
          $fout .= $oim_html;
          $fout .= '</li>';
        }

        $fout .= '</ul>';
      }


    }

    if ($oim['type'] == 'attach') {


      if (current_user_can('upload_files')) {
        $fout .= '<div class="dzs-wordpress-uploader here-uploader ">
 <a rel="nofollow" href="#" class="button-secondary';


        if (isset($oim['upload_btn_extra_classes']) && $oim['upload_btn_extra_classes']) {
          $fout .= ' ' . $oim['upload_btn_extra_classes'];
        }

        $fout .= '">' . esc_html__('Upload', 'dzsvp') . '</a>
</div>';


      }
//			    $fout.= $struct_uploader;
    }

    if (isset($oim['sidenote']) && $oim['sidenote']) {
      $fout .= '<div class="sidenote">' . $oim['sidenote'] . '</div>';
    }


    if (isset($oim['sidenote-2']) && $oim['sidenote-2']) {


      $sidenote_2_class = '';

      if (isset($oim['sidenote-2-class'])) {
        $sidenote_2_class = $oim['sidenote-2-class'];
      }
      $fout .= '<div class="sidenote-2 ' . $sidenote_2_class . '">' . $oim['sidenote-2'] . '</div>';
    }


    $fout .= '
                    </div>';


  }


  return $fout;
}


function dzsap_sliders_admin_init() {

  global $dzsap, $pagenow;
  $tax = DZSAP_TAXONOMY_NAME_SLIDERS;

  if(isset($_GET['taxonomy']) && $_GET['taxonomy']===DZSAP_TAXONOMY_NAME_SLIDERS &&  isset($_GET['post_type']) && $_GET['post_type']===DZSAP_REGISTER_POST_TYPE_NAME ){

    add_action( 'pre_get_posts', 'dzsap_slidersAdmin_fixHackConfictsForOrder' ,1000);
  }




  if ((isset($_REQUEST['action']) && 'dzsap_duplicate_slider_term' == $_REQUEST['action'])) {

    if (!(isset($_GET['term_id']) || isset($_POST['term_id']))) {
      wp_die("no term_id set");
    }


    /*
     * get the original post id
     */
    $term_id = (isset($_GET['term_id']) ? absint($_GET['term_id']) : absint($_POST['term_id']));

    $term_meta = get_option("taxonomy_$term_id");

    /*
    $current_user = wp_get_current_user();
    $new_post_author = $current_user->ID;



     * Nonce verification
     */
    if (isset($_GET['duplicate-nonce-for-term-id-' . $term_id]) && wp_verify_nonce($_GET['duplicate-nonce-for-term-id-' . $term_id], 'duplicate-nonce-for-term-id-' . $term_id)) {


      $args = array(
        'post_type' => 'dzsap_items',
        'tax_query' => array(
          array(
            'taxonomy' => DZSAP_TAXONOMY_NAME_SLIDERS,
            'field' => 'id',
            'terms' => $term_id
          )
        ),
      );
      $query = new WP_Query($args);


      $reference_term = get_term($term_id, $tax);


      $reference_term_name = $reference_term->name;
      $reference_term_slug = $reference_term->slug;

//			    print_rr($reference_term_name);
//			    print_rr($reference_term_slug);
//			    print_rr($query);


      $new_term_name = $reference_term_name . ' ' . esc_html("Copy", DZSAP_ID);
      $new_term_slug = $reference_term_slug . '-copy';
      $original_slug_name = $reference_term_slug . '-copy';


      $ind = 1;
      $breaker = 100;
      while (1) {

        $term = term_exists($new_term_slug, $tax);
        if ($term !== 0 && $term !== null) {

          $ind++;
          $new_term_slug = $original_slug_name . '-' . $ind;
        } else {
          break;
        }

        $breaker--;

        if ($breaker < 0) {
          break;
        }
      }


      $new_term = wp_insert_term(
        $new_term_name, // the term
        $tax, // the taxonomy
        array(

          'slug' => $new_term_slug,
        )
      );


      foreach ($query->posts as $po) {


        $dzsap->ajax_functions->duplicate_post($po->ID, array(
          'new_term_slug' => $new_term_slug,
          'call_from' => 'default',
          'new_tax' => $tax,
        ));


      }

//			$new_term = get_term_by('slug',$new_term_slug,$tax);

//            error_log(print_rr($new_term,array('echo'=>false)));
      $new_term_id = $new_term['term_id'];


      update_option("taxonomy_$new_term_id", $term_meta);
      wp_redirect(admin_url('term.php?taxonomy=' . $tax . '&tag_ID=' . $new_term_id . '&post_type=dzsap_items'));

      exit;


//		exit;
    } else {
      $aux = ('invalid nonce for term_id' . $term_id . 'duplicate-nonce-for-term-id-' . $term_id);

      $aux .= print_rr($_SESSION);

      $aux .= ' searched nonce - ' . $_GET['duplicate-nonce-for-term-id-' . $term_id];
      $aux .= ' searched nonce verify - ' . wp_verify_nonce($_GET['duplicate-nonce-for-term-id-' . $term_id], 'duplicate-nonce-for-term-id-' . $term_id);


      wp_die($aux);
    }
  }


  // -- export
  if ((isset($_REQUEST['action']) && 'dzsap_export_slider_term' == $_REQUEST['action'])) {


    /*
     * get the original post id
     */
    $term_id = (isset($_GET['term_id']) ? absint($_GET['term_id']) : absint($_POST['term_id']));


    $arr_export = $dzsap->classAdmin->playlist_export($term_id, array(
      'download_export' => true
    ));
    echo json_encode($arr_export);
    die();


    exit;

  }


  // -- import

  if (isset($_POST['action']) && $_POST['action'] == 'dzsap_import_slider') {

    if (isset($_FILES['dzsap_import_slider_file'])) {

      $file_arr = $_FILES['dzsap_import_slider_file'];

      $file_cont = file_get_contents($file_arr['tmp_name'], true);

//			print_rr($file_cont);


      $type = 'none';


      try {

        $arr = json_decode($file_cont, true);

        error_log('content - ' . print_rr($arr, true));

        if ($arr && is_array($arr)) {

          $type = 'json';
        } else {
          $arr = unserialize($file_cont);


          error_log('content - ' . print_rr($arr, true));
          $type = 'serial';
        }

        if (is_array($arr)) {
          if ($type == 'json') {


            $reference_term_name = $arr['original_term_name'];
            $reference_term_slug = $arr['original_term_slug'];

//			    print_rr($reference_term_name);
//			    print_rr($reference_term_slug);
//			    print_rr($query);
            $original_name = $reference_term_name;
            $original_slug = $reference_term_slug;


            $new_term_slug = $reference_term_slug;
            $new_term_name = $reference_term_name;


            $ind = 1;
            $breaker = 100;


            $term = term_exists($new_term_name, $tax);
            if ($term !== 0 && $term !== null) {


              $new_term_name = $original_name . '-' . $ind;
              $new_term_slug = $original_slug . '-' . $ind;
              $ind++;


              while (1) {

                $term = term_exists($new_term_name, $tax);
                if ($term !== 0 && $term !== null) {

                  $new_term_name = $original_name . '-' . $ind;
                  $new_term_slug = $original_slug . '-' . $ind;
                  $ind++;
                } else {
                  break;
                }

                $breaker--;

                if ($breaker < 0) {
                  break;
                }
              }

            } else {


            }


            $new_term = wp_insert_term(
              $new_term_name, // the term
              $tax, // the taxonomy
              array(

                'slug' => $new_term_slug,
              )
            );


            $new_term_id = '';
            if (is_array($new_term)) {

              $new_term_id = $new_term['term_id'];
            } else {
              error_log(' .. the name is ' . $new_term_name);
              error_log(print_r($new_term, true));
            }


            $term_meta = array_merge(array(), $arr['term_meta']);

            unset($term_meta['items']);

            update_option("taxonomy_$new_term_id", $term_meta);


            foreach ($arr['items'] as $po) {

              $args = array_merge(array(), $po);

              $args['term'] = $new_term_slug;
              $args['taxonomy'] = $tax;

              $args['call_from'] = 'sliders_admin import slider_file';
              $dzsap->ajax_functions->import_demo_insert_post_complete($args);


            }

//			$new_term = get_term_by('slug',$new_term_slug,$tax);

//            error_log(print_rr($new_term,array('echo'=>false)));


          }


          // -- legacy
          if ($type == 'serial') {


            $new_term_id = '';
            $new_term = null;
            $original_slug = '';


            foreach ($arr as $lab => $val) {


              if ($lab === 'settings') {


                $reference_term_name = $val['id'];
                $reference_term_slug = $val['id'];

//			    print_rr($reference_term_name);
//			    print_rr($reference_term_slug);
//			    print_rr($query);
                $original_name = $reference_term_name;
                $original_slug = $reference_term_slug;


                $new_term_slug = $reference_term_slug;
                $new_term_name = $reference_term_name;


                $ind = 1;
                $breaker = 100;


                $term = term_exists($new_term_slug, $tax);
                if ($term !== 0 && $term !== null) {


                  while (1) {

                    $term = term_exists($new_term_slug, $tax);
                    if ($term !== 0 && $term !== null) {

                      $ind++;
                      $new_term_slug = $original_slug . '-' . $ind;
                    } else {
                      break;
                    }

                    $breaker--;

                    if ($breaker < 0) {
                      break;
                    }
                  }

                  $ind++;
                  $new_term_name = $original_name . '-' . $ind;
                  $new_term_slug = $original_slug . '-' . $ind;
                } else {

                }


                $new_term = wp_insert_term(
                  $new_term_name, // the term
                  $tax, // the taxonomy
                  array(

                    'slug' => $new_term_slug,
                  )
                );


                if (is_array($new_term)) {

                  $new_term_id = $new_term['term_id'];
                } else {
                  error_log(' .. the name is ' . $new_term_name);
                  error_log(print_r($new_term, true));
                }


                $term_meta = array_merge(array(), $val);

                unset($term_meta['items']);

                update_option("taxonomy_$new_term_id", $term_meta);
              } else {

                $args = array_merge(array(), $val);

                $args['term'] = $new_term;
                $args['taxonomy'] = $tax;
                $args['post_name'] = $original_slug . '-' . $lab;
                $args['post_title'] = $original_slug . '-' . $lab;

                if (isset($args['menu_artistname'])) {
                  $args['post_title'] = $args['menu_artistname'];
                }
                if (isset($args['menu_songname'])) {
                  $args['post_content'] = $args['menu_songname'];
                }


                // -- admin init
                foreach ($dzsap->options_item_meta as $oim) {
                  $long_name = $oim['name'];

                  $short_name = str_replace('dzsap_meta_', '', $oim['name']);


                  $args[$long_name] = $args[$short_name];
                }


                $dzsap->ajax_functions->import_demo_insert_post_complete($args);

              }


            }
          }
        }
      } catch (Exception $err) {
        print_rr($err);
      }
    }
  }
}


function dzsap_action_dzsap_duplicate_slider_term() {


}

function dzsap_sliders_admin_duplicate_post_link($actions, $term) {

//    error_log(print_rr($term,array('echo'=>false)));
  if (current_user_can('edit_posts')) {


    // Create an nonce, and add it as a query var in a link to perform an action.
    $nonce = wp_create_nonce('duplicate-nonce-for-term-id-' . $term->term_id);

    $actions['duplicate'] = '<a href="' . admin_url('edit-tags.php?taxonomy=dzsap_sliders&post_type=dzsap_items&action=dzsap_duplicate_slider_term&term_id=' . $term->term_id) . '&duplicate-nonce-for-term-id-' . ($term->term_id) . '=' . $nonce . '" title="Duplicate this item" rel="permalink">' . esc_html("Duplicate", DZSAP_ID) . '</a>';
  }


  $actions['export'] = '<a href="' . admin_url('edit-tags.php?taxonomy=dzsap_sliders&post_type=dzsap_items&action=dzsap_export_slider_term&term_id=' . $term->term_id) . '" title="Duplicate this item" rel="permalink">' . esc_html("Export", DZSAP_ID) . '</a>';


  return $actions;
}


function dzsap_sliders_admin() {

  if (isset($_GET['taxonomy']) && $_GET['taxonomy'] == DZSAP_TAXONOMY_NAME_SLIDERS) {


    //&& isset($_GET['tag_ID'])
    global $dzsap;


    $tax = DZSAP_TAXONOMY_NAME_SLIDERS;


//        echo 'here <strong>sliders_admin.php</strong> ';

    wp_enqueue_style('dzs.dzstoggle', DZSAP_BASE_URL . 'libs/dzstoggle/dzstoggle.css');
    wp_enqueue_script('dzs.dzstoggle', DZSAP_BASE_URL . 'libs/dzstoggle/dzstoggle.js');

    DZSZoomSoundsHelper::embedZoomTabsAndAccordions();

    wp_enqueue_script('sliders_admin', DZSAP_BASE_URL . 'admin/sliders_admin.js');
    wp_enqueue_script('dzs.farbtastic', DZSAP_BASE_URL . "libs/farbtastic/farbtastic.js");
    wp_enqueue_style('dzs.farbtastic', DZSAP_BASE_URL . 'libs/farbtastic/farbtastic.css');


    $terms = get_terms($tax, array(
      'hide_empty' => false,
    ));

//        print_r($terms);


    $i23 = 0;

//	    $dzsap->db_read_mainitems();

//        print_r($dzsap);

//	    print_rr($dzsap->options_slider);


    $selectedTermId = null;
    $foundTermObject = null;
    $selected_term_id = '';
    $selected_term_name = '';
    $selected_term_slug = '';
    if (isset($_GET['tag_ID'])) {

      $foundTermObject = get_term($_GET['tag_ID'], $tax);


      if (isset($foundTermObject)) {

        $selected_term_id = $foundTermObject->term_id;
        $selected_term_name = $foundTermObject->name;
        $selected_term_slug = $foundTermObject->slug;
      }


      if (isset($_GET['tag_ID'])) {
        $selectedTermId = $_GET['tag_ID'];

//		        $term = get_term($_GET['tag_ID'], $tax);
//		        $selected_term_name = $term->name;

//            print_r($term);
      }
    }


    $term_meta = get_option("taxonomy_$selectedTermId");


//        echo $selected_term;


    ?>



  <div class="dzsap-sliders-con" data-term_id="<?php echo $selected_term_id; ?>"
       data-term-slug="<?php echo $selected_term_slug; ?>">

    <h3 class="slider-label" style="font-weight: normal">
      <span><?php echo __("Editing "); ?></span><span
        style="font-weight: bold;"><?php echo $selected_term_name; ?></span> <span class="slider-status empty ">
                <div class="slider-status--inner loading"><i class="fa fa-circle-o-notch fa-spin"
                                                             aria-hidden="true"></i> <span
                    class="text-label"><?php echo __("Saving"); ?></span></div>
            </span>
    </h3>


    <div class="dzsap-slider-items">

    <?php

    if ($selectedTermId) {


      global $dzsap_slidersAdmin_fixHackConfictsForOrder_metaQuery;

      $dzsap_slidersAdmin_fixHackConfictsForOrder_metaQuery = array(
        'relation' => 'OR',
        array(
          'key' => 'dzsap_meta_order_' . $selectedTermId,
          //                        'value' => '',
          'compare' => 'EXISTS',
        ),
        array(
          'key' => 'dzsap_meta_order_' . $selectedTermId,
          //                        'value' => '',
          'compare' => 'NOT EXISTS'
        )
      );
      $args = array(
        'post_type' => 'dzsap_items',
        'numberposts' => -1,
        'posts_per_page' => '-1',
        //                'meta_key' => 'dzsap_meta_order_'.$selected_term,

        'orderby' => 'meta_value_num',
        'order' => 'ASC',
        'meta_query' => $dzsap_slidersAdmin_fixHackConfictsForOrder_metaQuery,
        'tax_query' => array(
          array(
            'taxonomy' => $tax,
            'field' => 'id',
            'terms' => $selectedTermId
          )
        ),
      );

      $manualItemsQuery = new WP_Query($args);
      $manualItemsQueryPosts = $manualItemsQuery->posts;
//      $manualItemsQueryPosts = get_posts($args);



      foreach ($manualItemsQueryPosts as $po) {

//                print_r($po);
        echo dzsap_sliders_admin_generate_item($po);


      }
      $object = (object)array(
        'ID' => 'placeholder',
        'post_title' => 'placeholder',
      );
//           echo  $dzsap->sliders_admin_generate_item($object)
      ?>

      </div>

      <div class="add-btn">
        <i class="fa fa-plus-circle add-btn--icon"></i>
        <div class="add-btn-new button-secondary"><?php echo esc_html__("Create New Item", DZSAP_ID); ?></div>
        <div
          class="add-btn-existing add-btn-existing-media upload-type-audio button-secondary"><?php echo esc_html__("Add From Library", DZSAP_ID); ?></div>
      </div>

      <br>
      <br>


      <div id="tabs-box" class="dzs-tabs  skin-qcre " data-options='{ "design_tabsposition" : "top"
,"design_transition": "fade"
,"design_tabswidth": "default"
,"toggle_breakpoint" : "200"
,"settings_appendWholeContent": "true"
,"toggle_type": "accordion"
}
'>

        <div class="dzs-tab-tobe">
          <div class="tab-menu ">
            <?php
            echo esc_html__("Main Settings", DZSAP_ID);
            ?>
          </div>
          <div class="tab-content tab-content-cat-main">


          </div>
        </div>


        <?php
        foreach ($dzsap->options_slider_categories_lng as $lab => $val) {


          ?>

          <div class="dzs-tab-tobe">
          <div class="tab-menu ">
            <?php
            echo($val);
            ?>
          </div>
          <div class="tab-content tab-content-cat-<?php echo $lab; ?>">


            <table class="form-table custom-form-table sa-category-<?php echo $lab; ?>">
              <tbody>
              <?php
              dzsap_sliders_admin_parse_options($foundTermObject, $lab);
              ?>
              </tbody>

            </table>

          </div>
          </div><?php

        }
        ?>


      </div><!-- end .dzs-tabs -->


      <div class="feed-con import-folder-con for-feed_mode-import-folder">

        <div class="dzstoggle toggle1" rel="">
          <div class="toggle-title" style=""><?php echo esc_html__('Import folder', DZSAP_ID); ?></div>
          <div class="toggle-content">

            <h4><?php echo esc_html__("Import folder", DZSAP_ID); ?></h4>
            <?php
            $val = '';
            $lab = 'folder_location';
            if (isset($term_meta[$lab])) {
              $val = $term_meta[$lab];
            }
            ?>


            <input type="text" class="big-rounded-field" data-aux-name="<?php echo $lab; ?>"
                   value="<?php echo $val; ?>"/>
            <div
              class="sidenote"><?php echo esc_html__("input the location of the folder that is storing the mp3s - for example the location of the zoomsounds plugin folder is ", DZSAP_ID);
              echo '<strong>' . wp_upload_dir()['basedir'] . '</strong>'; ?></div>
            <div class="button-con align-inside-middle">

              <button
                class="button-secondary btn-import-folder"><?php echo esc_html__("Import folder", DZSAP_ID); ?></button>
              <span class="dzsap-dashicon-preloader dashicons dashicons-update"></span>
            </div>

          </div>
        </div>

        <?php
        if($dzsap->mainoptions['debug_queries']==='on'){
          ?>


          <div class="dzstoggle toggle1" rel="">
            <div class="toggle-title" style=""><?php echo esc_html__('Debug queries', DZSAP_ID); ?></div>
            <div class="toggle-content"><?php
              if(isset($manualItemsQuery)){

                print_rr($manualItemsQuery);
              }else{
                print_rr($manualItemsQueryPosts);
              }
              ?>></div>
          </div>
          <?php

        }
        ?>
      </div>


      <div class="dzsap-sliders">
        <table class="wp-list-table widefat fixed striped tags">
          <thead>
          <tr>


            <th scope="col" id="name" class="manage-column column-name column-primary sortable desc"><a
                href="<?= admin_url('edit-tags.php?taxonomy='.DZSAP_TAXONOMY_NAME_SLIDERS.'&amp;post_type='.DZSAP_REGISTER_POST_TYPE_NAME.'&amp;orderby=name&amp;order=asc'); ?>"><span>Name</span><span
                  class="sorting-indicator"></span></a></th>


            <th scope="col" id="slug" class="manage-column column-slug sortable desc"><a
                href="<?= admin_url('edit-tags.php?taxonomy='.DZSAP_TAXONOMY_NAME_SLIDERS.'&amp;post_type='.DZSAP_REGISTER_POST_TYPE_NAME.'&amp;orderby=slug&amp;order=asc'); ?>"><span><?php echo __("Edit"); ?></span><span
                  class="sorting-indicator"></span></a></th>

            <th scope="col" id="posts" class="manage-column column-posts num sortable desc"><a
                href="<?= admin_url('edit-tags.php?taxonomy='.DZSAP_TAXONOMY_NAME_SLIDERS.'&amp;post_type='.DZSAP_REGISTER_POST_TYPE_NAME.'&amp;orderby=count&amp;order=asc'); ?>"><span>Count</span><span
                  class="sorting-indicator"></span></a></th>
          </tr>
          </thead>

          <tbody id="the-list" data-wp-lists="list:tag">


          <?php


          foreach ($terms as $tm) {

            ?>


            <tr id="tag-<?php echo $tm->term_id; ?>">

              <td class="name column-name has-row-actions column-primary" data-colname="Name"><strong>
                  <a class="row-title"
                     href="<?php echo site_url(); ?>/wp-admin/term.php?taxonomy=dzsap_sliders&amp;tag_ID=<?php echo $tm->term_id; ?>&amp;post_type=dzsap_items&amp;wp_http_referer=%2Fwordpress%2Fwp-admin%2Fedit-tags.php%3Ftaxonomy%3Ddzsap_sliders%26post_type%3Ddzsap_items"
                     aria-label="“<?php echo $tm->name; ?>” (Edit)"><?php echo $tm->name; ?></a></strong>
                <br>
                <div class="hidden" id="inline_<?php echo $tm->term_id; ?>">

                  <div class="name"><?php echo $tm->name; ?></div>
                  <div class="slug"><?php echo $tm->slug; ?></div>
                  <div class="parent">0</div>
                </div>
                <div class="row-actions">

                  <span class="edit"><a
                      href="<?php echo site_url(); ?>/wp-admin/term.php?taxonomy=dzsap_sliders&amp;tag_ID=<?php echo $tm->term_id; ?>&amp;post_type=dzsap_items&amp;wp_http_referer=%2Fwordpress%2Fwp-admin%2Fedit-tags.php%3Ftaxonomy%3Ddzsap_sliders%26post_type%3Ddzsap_items"
                      aria-label="Edit “Test 1”">Edit</a> | </span>

                  <span class="delete"><a
                      href="<?= admin_url('edit-tags.php?action=delete&amp;taxonomy=dzsap_sliders&amp;tag_ID='.$tm->term_id.'&amp;_wpnonce='.wp_create_nonce('delete-tag_' . $tm->term_id).''); ?>"
                      class="delete-tag aria-button-if-js" aria-label="Delete “<?php echo $tm->name; ?>”" role="button">Delete</a> | </span><span
                    class="view"><a href="<?php echo site_url(); ?>/audio-sliders/test-1/"
                                    aria-label="View “Test 1” archive">View</a></span></div>
                <button type="button" class="toggle-row"><span class="screen-reader-text">Show more details</span>
                </button>
              </td>

              <td class="description column-description" data-colname="Description">Edit</td>

              <td class="slug column-slug" data-colname="Slug"><?php echo $tm->count; ?></td>
            </tr>
            <?php
          }
          ?>


          </tbody>


        </table>

      </div>


      </div>


      <?php
    } else {
      echo '</div></div>';
      ?>


      <form class="import-slider-form" style="display: none;" enctype="multipart/form-data" action="" method="POST">
        <h3>Import Slider</h3>
        <p><input name="dzsap_import_slider_file" type="file" size="10"/></p>
        <button class="button-secondary" type="submit" name="action"
                value="dzsap_import_slider"><?php echo esc_html__("Import"); ?></button>
        <div class="clear"></div>
        <?php


        ?>
      </form>
      <?php
    }
    ?>
    <div class="feedbacker"><?php echo esc_html__("Loading..."); ?></div><?php
  }
}


function dzsap_sliders_admin_add_feature_group_field($term) {

//    echo 'cevadada';


  global $dzsap;


//    error_log('ceva3');


  $dzsap->options_slider = include DZSAP_BASE_PATH . 'configs/playlist-options.php';


  $dzsap->options_slider_categories_lng = array(
    'appearence' => esc_html__("Appearance", DZSAP_ID),
    'menu' => esc_html__("Menu", DZSAP_ID),
    'autoplay' => esc_html__("Play Options", DZSAP_ID),
    'counters' => esc_html__("Counters", DZSAP_ID),
  );


//	'misc'=>esc_html__("Miscellaneous",DZSAP_ID),


  $i23 = 0;
  foreach ($dzsap->mainitems_configs as $vpconfig) {
    //print_r($vpconfig);


    $aux = array(
      'label' => $vpconfig['settings']['id'],
      'value' => $vpconfig['settings']['id'],
    );

//            print_rr($aux);


    foreach ($dzsap->options_slider as $lab => $so) {

      if ($so['name'] == 'vpconfig') {

//	                print_rr($aux);


        array_push($dzsap->options_slider[$lab]['options'], $aux);

        break;
      }
    }


    $i23++;
  }


  dzsap_sliders_admin_parse_options($term, 'main');


}

function dzsap_sliders_admin_parse_options($term, $cat = 'main') {

  global $dzsap;
  $indtem = 0;


  $t_id = $term->term_id;

  // retrieve the existing value(s) for this meta field. This returns an array
  $term_meta = get_option("taxonomy_$t_id");

//	echo '$term_meta - '; print_rr($term_meta);


  // -- we need real location, not insert-id

  $struct_uploader = '<div class="dzs-wordpress-uploader ">
<a href="#" class="button-secondary">' . __('Upload', 'dzsvp') . '</a>
</div>';

  foreach ($dzsap->options_slider as $sliderOption) {


//	    echo '$indtem - '.$indtem;
//	    echo '$indtem%2 - '.($indtem%2);


    if ($cat == 'main') {

      if (isset($sliderOption['category']) == false || (isset($sliderOption['category']) && $sliderOption['category'] == 'main')) {

      } else {
        continue;
      }
    } else {

      if ((isset($sliderOption['category']) && $sliderOption['category'] == $cat)) {

      } else {
        continue;
      }
    }
    if (!isset($sliderOption['title'])) {
      continue;
    }
    if ($indtem % 2 === 0) {
//			echo '<tr class="clear"></tr>';

//	        echo 'yes';
    }


    if (isset($sliderOption['choices'])) {
      $sliderOption['options'] = $sliderOption['choices'];
    }

    if (isset($sliderOption['sidenote'])) {
      $sliderOption['description'] = $sliderOption['sidenote'];
    }
    ?>
    <tr class="form-field" <?php


    if (isset($sliderOption['dependency'])) {

      echo ' data-dependency=\'' . json_encode($sliderOption['dependency']) . '\'';
    }

    ?>>
      <th scope="row" valign="top"><label
          for="term_meta[<?php echo $sliderOption['name']; ?>]"><?php echo $sliderOption['title']; ?></label></th>
      <td class="<?php
      if ($sliderOption['type'] == 'media-upload') {
        echo 'setting-upload';
      }
      ?>">


        <?php
        // -- main options

        if ($sliderOption['type'] == 'media-upload' || $sliderOption['type'] == 'color') {
          echo '<div class="uploader-three-floats">';
        }

        if ($sliderOption['type'] == 'media-upload') {
          echo '<span class="uploader-preview"></span>';
        }
        ?>



        <?php
        $lab = 'term_meta[' . $sliderOption['name'] . ']';

        $val = '';

        if (isset($term_meta[$sliderOption['name']])) {

          $val = esc_attr($term_meta[$sliderOption['name']]) ? esc_attr($term_meta[$sliderOption['name']]) : '';
        }

        $class = 'setting-field medium';


        if ($sliderOption['type'] == 'media-upload') {
          $class .= ' uploader-target';
        }

        if ($sliderOption['type'] == 'color') {
          $class .= ' wp-color-picker-init';
        }
        if ($sliderOption['type'] == 'media-upload' || $sliderOption['type'] == 'text' || $sliderOption['type'] == 'input' || $sliderOption['type'] == 'color') {


          if ($sliderOption['type'] == 'color') {
            $class .= ' with_colorpicker';
          }

          echo DZSHelpers::generate_input_text($lab, array(
            'class' => $class,
            'seekval' => $val,
            'id' => $lab,
          ));

        }


        if ($sliderOption['type'] == 'select') {

//				    print_rr($tem);


          $class .= ' dzs-style-me skin-beige';

          if (isset($sliderOption['select_type'])) {
            $class .= ' ' . $sliderOption['select_type'];
          }
          if (isset($sliderOption['extra_classes'])) {
            $class .= ' ' . $sliderOption['extra_classes'];
          }
          $class .= ' dzs-dependency-field';
          echo DZSHelpers::generate_select($lab, array(
            'class' => $class,
            'options' => $sliderOption['options'],
            'seekval' => $val,
            'id' => $lab,
          ));


          if (isset($sliderOption['select_type']) && $sliderOption['select_type'] == 'opener-listbuttons') {

            echo '<ul class="dzs-style-me-feeder">';

            foreach ($sliderOption['choices_html'] as $oim_html) {

              echo '<li>';
              echo $oim_html;
              echo '</li>';
            }

            echo '</ul>';


          }
        }

        if ($sliderOption['type'] == 'color') {
//                DZSHelpers::generate_input_text($lab, array('val' => '', 'class' => 'wp-color-picker-init ', 'seekval' => $val));


          echo '<div class="picker-con"><div class="the-icon"></div><div class="picker"></div></div>';
        }


        // -- media upload
        if ($sliderOption['type'] == 'media-upload') {

          echo '<div class="dzs-wordpress-uploader here-uploader ">
<a href="#" class="button-secondary';


          if (isset($sliderOption['upload_btn_extra_classes']) && $sliderOption['upload_btn_extra_classes']) {
            echo ' ' . $sliderOption['upload_btn_extra_classes'];
          }


          echo '">' . __('Upload', 'dzsvp') . '</a>
</div>';
//					echo $struct_uploader;
        }
        ?>
        <?php


        if ($sliderOption['type'] == 'media-upload' || $sliderOption['type'] == 'color') {
          echo '</div><!-- end uploader three floats -->';
        }

        $description = '';
        if (isset($sliderOption['description'])) {
          $description = $sliderOption['description'];
        }

        if ($description) {
          ?>
          <p class="description"><?php echo $description; ?></p>
          <?php


        }
        ?>
      </td>
    </tr>
    <?php

    $indtem++;
  }

}