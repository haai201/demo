<?php


define('DZSAP_ID', 'dzsap');
define('DZSAP_PREFIX_LOWERCASE', 'dzsap');
define('DZSAP_REGISTER_POST_TYPE_NAME', 'dzsap_items');
define('DZSAP_REGISTER_POST_TYPE_CATEGORY', 'dzsap_category');
define('DZSAP_REGISTER_POST_TYPE_TAGS', 'dzsap_tags');
define('DZSAP_DBNAME_OPTIONS', 'dzsap_options');
define('DZSAP_TAXONOMY_NAME_SLIDERS', 'dzsap_sliders');
define('DZSAP_PERMISSION_ULTIMATE', 'manage_options');
define('DZSAP_DBNAME_MAINITEMS', 'dzsap_items');
define('DZSAP_DBNAME_LEGACY_DBS', 'dzsap_dbs');
define('DZSAP_DBNAME_AUDIO_PLAYERS_CONFIGS', 'dzsap_vpconfigs');
define('DZSAP_DBNAME_MAINOPTIONS', 'dzsap_options');
define('DZSAP_DBNAME_SAMPLEDATA', 'dzsap_sample_data');
define('DZSAP_DBNAME_PCM_LINKS', 'dzsap_pcm_to_id_links'); // -- pcm bindings
define('DZSAP_META_OPTION_PREFIX', 'dzsap_meta_');
define('DZSAP_PHP_LOG_LABEL', '[dzsap]');
define('DZSAP_PHP_LOG_AJAX_LABEL', '[ajax]');
define('DZSAP_ADMIN_PAGENAME_PARENT', 'dzsap_menu');
define('DZSAP_ADMIN_PAGENAME_AUTOUPDATER', 'dzsap-autoupdater');
define('DZSAP_ADMIN_PAGENAME_LEGACY_SLIDERS_ADMIN_VPCONFIGS', 'dzsap_configs');
define('DZSAP_ADMIN_PAGENAME_LEGACY_SLIDERS_ADMIN_SLIDERS', 'dzsap_menu');
define('DZSAP_ADMIN_PAGENAME_DESIGNER_CENTER', 'dzsap-dc');
define('DZSAP_ADMIN_PAGENAME_MAINOPTIONS', 'dzsap-mo');
define('DZSAP_ADMIN_PAGENAME_MAINOPTIONS_WAVE_GENERATOR', 'dzsap_wave_regenerate');
define('DZSAP_ADMIN_PAGENAME_MAINOPTIONS_WAVE_GENERATOR_AUTO_GENERATE_PARAM', 'dzsap_wave_generate_auto');
define('DZSAP_ADMIN_PAGENAME_ABOUT', 'dzsap-about');
define('DZSAP_VPCONFIGS_DEFAULT_SETTINGS_NAME', 'default-settings-for-zoomsounds');
define('DZSAP_ZOOMSOUNDS_ACRONYM', 'zoomsounds');
define('DZSAP_DB_PLAYLIST_META_NAME', '_dzsap_views');
define('DZSAP_DEFAULT_ZOOMSOUNDS_CONFIG', 'default-settings-for-zoomsounds');
define('DZSAP_COOKIENAME_SYSTEM_CHECK_WAVES', 'dzsap_is_admin_systemCheck_waves');
define('DZSAP_VIEW_SHOWCASE_PLAYLIST_ID', 'playlist_gallery');
define('DZSAP_VIEW_NONCE_IDENTIFIER', 'generatenonce');
define('DZSAP_VIEW_EMBED_IFRAME_HEIGHT', '180');