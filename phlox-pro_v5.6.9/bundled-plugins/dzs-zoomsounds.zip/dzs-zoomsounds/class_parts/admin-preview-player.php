<?php

function dzsap_preview_player__headScripts() {


  ?>
  <style>
      .wrap-for-player-preview {
          position: relative;
          background-color: #5a5959;
          height: 100vh;

      }

      body:not(.this-is-for-preview-player-ACTUALLY) {

          background-color: #5a5959;
      }

      html:not(.this-is-for-preview-player-ACTUALLY) {
          margin-top: 0 !important;
          padding-top: 0 !important;
          overflow: hidden;
          background-color: #5a5959;

          width: 780px;
          height: 600px;

          /*width: 100%;*/
      }

      html #wpcontent {
          margin: 0 !important;
          padding: 0 !important;
      }

      html #wpcontent .wrap {
          margin: 0 !important;
          padding: 10px !important;
          height: 300px;
          padding: 10px;
      }

      html #wpcontent .audioplayer {
          position: absolute;
          top: 50%;
          transform: translate3d(0, -50%, 0);
      }
  </style><?php
}

function dzsap_preview_player() {

  global $dzsap;
  ?>
  <div class="wrap wrap-for-player-preview">
    <?php


    $config = '';

    if (isset($_GET['config']) && $_GET['config']) {
      $config = $_GET['config'];
    }
    $args = array(
      'source' => 'https://soundbible.com/mp3/Hummingbird-SoundBible.com-623295865.mp3',
      'config' => $config,
      'artistname' => 'artist',
      'songname' => 'song',
      'thumb' => 'https://i.imgur.com/jCLdxjj.jpg',
    );

    echo $dzsap->classView->shortcode_player($args);
    ?>
  </div><?php

}