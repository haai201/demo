<?php
function dzsap_view_embed_init_listeners(){




  add_action('wp_enqueue_scripts', 'dzsap_view_embed_handle_wp_enqueue_scripts', 500);
}

function dzsap_view_embed_handle_wp_enqueue_scripts(){

  if (isset($_GET['action'])) {
    if ($_GET['action'] == 'embed_zoomsounds') {
      DZSZoomSoundsHelper::enqueueMainScrips();

      // -- embedded css
      ?>
      <style>
          html:not(.a):not(.a), body:not(.a):not(.a) {
              background-color: transparent;
          }

          body > * {
              display: none !important;
          }

          body > .dzsap-main-con {
              display: block !important;
          }

          body .zoomsounds-embed-con {
              display: block !important;
              position: fixed;
              top: 0;
              left: 0;
              width: 100%;
          }
      </style>
      <script>
        document.addEventListener("DOMContentLoaded", function () {
          var nodes = document.querySelector('.zoomsounds-embed-con');
          document.body.append(nodes);
        });
      </script><?php
    }
  }
}

function dzsap_view_embed_generateHtml() {

  global $dzsap;





  echo '<div class="zoomsounds-embed-con">';

  $shortcodePlayerAtts = array();
  if (isset($_GET['type']) && $_GET['type'] == 'gallery') {

    $shortcodePlayerAtts = array(
      'id' => $_GET['id'],
      'embedded' => 'on',
    );


    if (isset($_GET['db'])) {
      $shortcodePlayerAtts['db'] = $_GET['db'];
    };
    echo $dzsap->classView->shortcode_playlist_main($shortcodePlayerAtts);

  }
  if (isset($_GET['type']) && $_GET['type'] == 'playlist') {

    $shortcodePlayerAtts = array(
      'ids' => $_GET['ids'],
      'embedded' => 'on',
    );


    if (isset($_GET['db'])) {
      $shortcodePlayerAtts['db'] = $_GET['db'];
    };
    echo $dzsap->classView->shortcode_playlist_main($shortcodePlayerAtts);

  }


  if (isset($_GET['type']) && $_GET['type'] == 'player') {


//    echo $_GET['margs'];
    $shortcodePlayerAtts = array();
    try {
//        echo '.'.stripslashes($_GET['margs']).'.';
      $shortcodePlayerAtts = @unserialize((stripslashes($_GET['margs'])));
    } catch (Exception $e) {

//        $args = array();
    }


//    print_r($args);

    if (is_array($shortcodePlayerAtts)) {

    } else {
      $shortcodePlayerAtts = array();


//        echo 'try json decode -> ';
//        echo stripslashes(stripslashes($_GET['margs']));
//        echo ' <- ';
//
//        echo '
//        try json decode -> ';
//        echo (stripslashes($_GET['margs']));
//        echo ' <- ';


      $shortcodePlayerAtts = json_decode((stripslashes(base64_decode($_GET['margs']))), true);

//        print_rr($args);

      if (is_object($shortcodePlayerAtts) || is_array($shortcodePlayerAtts)) {

      } else {
        $shortcodePlayerAtts = array();
      }

    }
//    print_r($args);
    $shortcodePlayerAtts['embedded'] = 'on';
    $shortcodePlayerAtts['extra_classes'] = ' test';
    $shortcodePlayerAtts['called_from'] = 'embed';

//          echo ' args for embed - '; print_rr($shortcodePlayerAtts);

    echo $dzsap->classView->shortcode_player($shortcodePlayerAtts);

  }
  echo '</div>';
}
