
import './block_player.scss';
import './block_player.js';