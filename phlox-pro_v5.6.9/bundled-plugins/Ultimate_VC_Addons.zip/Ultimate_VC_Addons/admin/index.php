<?php
/*Silence is Golden*/ // PHPCS:ignore:Squiz.Commenting.FileComment.WrongStyle
